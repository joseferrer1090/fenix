$(document).ready(function() {
   $('#log-tbl').footable();
});